#ifndef __ICEORYXVERSIONS__
#define __ICEORYXVERSIONS__

#define ICEORYX_VERSION_MAJOR    2
#define ICEORYX_VERSION_MINOR    90
#define ICEORYX_VERSION_PATCH    0
#define ICEORYX_VERSION_TWEAK    0

#define ICEORYX_LATEST_RELEASE_VERSION    "2.90.0"
#define ICEORYX_BUILDDATE                 "2023-09-12T06:41:47Z"
#define ICEORYX_SHA1                      "414784e169ba58666a9b4c0be087ea3e043ae839-dirty"

#include "iox/logging.hpp"

#define ICEORYX_PRINT_BUILDINFO()     IOX_LOG(INFO) << "Built: " << ICEORYX_BUILDDATE;


#endif
