# iceoryx v2.0.2

## [v2.0.2](https://github.com/eclipse-iceoryx/iceoryx/tree/v2.0.2) (2022-04-08)

[Full Changelog](https://github.com/eclipse-iceoryx/iceoryx/compare/v2.0.1...v2.0.2)

**Bugfixes:**

- Double build issue in ROS2 build farm [\#1323](https://github.com/eclipse-iceoryx/iceoryx/issues/1323)
