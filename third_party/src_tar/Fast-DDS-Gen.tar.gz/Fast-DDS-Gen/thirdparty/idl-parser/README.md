# IDL Parser

*eProsima IDL Parser* is a Java library that provides API to extract information about an IDL file defined following the [OMG Interface Definition Language specification](https://www.omg.org/spec/IDL/4.2/About-IDL).
