package com.eprosima.fastcdr.idl.util;

public class CdrVersion
{
    public enum Select
    {
        V1,
        V2,
        BOTH
    }

    public static String v1_str = "v1";
    public static String v2_str = "v2";
    public static String both_str = "both";
}
