#ifndef CUNIT_AUTOMATED_H
#define CUNIT_AUTOMATED_H

#include "ucunit/ucunit.h"

#endif /* CUNIT_AUTOMATED_H */
