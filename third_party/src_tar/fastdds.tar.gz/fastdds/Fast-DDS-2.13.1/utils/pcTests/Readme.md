The files on this folder were removed on release 2.0.0.
You can find them on an eariler commit like 852db23cc121652c4f513c43bb2b9a5bb90b1ab6 or
on a previous release like [1.10.0](https://github.com/eProsima/Fast-RTPS/tree/1.10.x/utils/pcTests)