To launch this test open two different consoles:

In the first one launch: ./DDSWriterLoansExample publisher (or DDSWriterLoansExample.exe publisher on windows).
In the second one: ./DDSWriterLoansExample subscriber (or DDSWriterLoansExample.exe subscriber on windows).

